package zdfs;

import static org.junit.Assert.assertNotNull;

import java.sql.SQLException;
import java.util.Calendar;
import java.util.Date;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import zdfs.util.AgeUtil;

//@Ignore
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations={"classpath:applicationContext.xml"})
public class DataSourceTest {

	@Resource(name="dataSource")
	private DataSource dataSource;
	@Resource(name="tf02_dataSource")
	private DataSource tf02_dataSource;
	
	private static Logger log=LogManager.getLogger();
	
	public DataSourceTest() {
		// TODO Auto-generated constructor stub
	}
	
	//@Test
	public void testDataSourceNotNull() throws SQLException{
		
		Assert.assertNotNull(dataSource);
		Assert.assertNotNull(tf02_dataSource);
		
		Assert.assertNotNull(dataSource.getConnection());
		Assert.assertNotNull(tf02_dataSource.getConnection());
		
		
	}

	
	//@Test
	public void testTF02DataSourceNotNull(){
		Calendar cal=Calendar.getInstance();
			cal.setTime(new Date(744220800000l));
			
			int year=cal.get(Calendar.YEAR);
			
			System.out.println("year:"+year);
			
			System.out.println(AgeUtil.computeAgeByBirthday(new Date(744220800000l)));
	}
	
	@Test
	public void test(){
		Calendar cal=Calendar.getInstance();
			cal.setTime(new Date());
			
			long start=cal.getTimeInMillis();
			
			cal.add(Calendar.MINUTE, 30);
			long end=cal.getTimeInMillis();
			//int hour=cal.getFirstDayOfWeek()
			

			cal.set(Calendar.HOUR_OF_DAY, 0);
			cal.set(Calendar.MINUTE, 0);
			cal.set(Calendar.MILLISECOND, 0);
			
			
			System.out.println("date:"+cal.getTimeInMillis());
			
			System.out.println("start:"+start+" end:"+end);
			
	}
	
}
