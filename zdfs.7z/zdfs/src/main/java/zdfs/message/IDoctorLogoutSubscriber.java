package zdfs.message;

public interface IDoctorLogoutSubscriber {

	void handleMessage(String message,String channel);
}
