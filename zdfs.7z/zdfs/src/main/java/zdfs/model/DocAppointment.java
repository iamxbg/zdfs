package zdfs.model;

import java.util.Date;

public class DocAppointment {
    private Integer id;

    private String docId;

    private Date appointTimeStart;

    private Date appointTimeEnd;

    private Integer appointmentNum;

    private Integer alreadyNum;

    private Date createTime;

    private Boolean delflag;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getDocId() {
        return docId;
    }

    public void setDocId(String docId) {
        this.docId = docId == null ? null : docId.trim();
    }

    public Date getAppointTimeStart() {
        return appointTimeStart;
    }

    public void setAppointTimeStart(Date appointTimeStart) {
        this.appointTimeStart = appointTimeStart;
    }

    public Date getAppointTimeEnd() {
        return appointTimeEnd;
    }

    public void setAppointTimeEnd(Date appointTimeEnd) {
        this.appointTimeEnd = appointTimeEnd;
    }

    public Integer getAppointmentNum() {
        return appointmentNum;
    }

    public void setAppointmentNum(Integer appointmentNum) {
        this.appointmentNum = appointmentNum;
    }

    public Integer getAlreadyNum() {
        return alreadyNum;
    }

    public void setAlreadyNum(Integer alreadyNum) {
        this.alreadyNum = alreadyNum;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Boolean getDelflag() {
        return delflag;
    }

    public void setDelflag(Boolean delflag) {
        this.delflag = delflag;
    }
}