package zdfs.message;

public interface IDoctorLoginSubscriber {

	void handleMessage(String message,String channel);
}
