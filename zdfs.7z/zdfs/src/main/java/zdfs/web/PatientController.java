package zdfs.web;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisOperations;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import static zdfs.message.MessageUtil.*;
import zdfs.message.MessageUtil;
import zdfs.model.DiagnoseT;
import zdfs.model.DoctorT;
import zdfs.model.PatientT;
import zdfs.model.PatientTExample;
import zdfs.service.IDiagnoseService;
import zdfs.service.IDoctorService;
import zdfs.service.IPatientService;
import zdfs.tf02.dao.TodayRemindMapper;
import zdfs.tf02.model.BfData;
import zdfs.tf02.model.BpData;
import zdfs.tf02.model.EcgData;
import zdfs.tf02.model.GluData;
import zdfs.tf02.model.MembersInfo;
import zdfs.tf02.model.Rspo2Data;
import zdfs.tf02.model.TodayRemind;
import zdfs.tf02.model.TodayRemindExample;
import zdfs.tf02.service.IHealthDataService;
import zdfs.tf02.service.IMembersInfoService;
import zdfs.util.AgeUtil;
import zdfs.web.param.ResponseParam;

@RestController
@RequestMapping(path="/patient")
public class PatientController {

	@Autowired
	private IPatientService pService;
	@Autowired
	private IMembersInfoService miService;
	@Autowired
	private IHealthDataService hdService;
	@Autowired
	private IDiagnoseService diagService;
	@Autowired
	private TodayRemindMapper trMapper;
	
	@Autowired
	private IHealthDataService hService;
	@Autowired
	private IDoctorService docService;
	
	@Autowired
	private RedisOperations<String, String> oprs;

	
	private static Logger log=LogManager.getLogger();
	
	public PatientController() {
		// TODO Auto-generated constructor stub
	}

	
	@ResponseBody
	@RequestMapping(path="/findByDoctorId",method=RequestMethod.POST)
	public ResponseParam<PatientT> findByDoctorId(@RequestBody Map<String, Object> params) throws ParseException {

		Integer doctorId=(Integer)params.get("doctorId");
		Date startDate=new SimpleDateFormat("yyyy-MM-dd").parse((String)params.get("startDateStr"));
		Date endDate=new SimpleDateFormat("yyyy-MM-dd").parse((String)params.get("endDateStr"));
		

		List<PatientT> dList=pService.findByDoctorIdAndLastestVideoTime(doctorId, startDate, endDate);
		
		for(PatientT p:dList){
			List<DiagnoseT> diagList=diagService.findByPatientId(p.getP_id());
			p.setDiagnoseList(diagList);
		}
		
		return new ResponseParam<>(dList);
	
	}
	
	@ResponseBody
	@RequestMapping(path="/findByDoctorIdHavingReminder/doctorId={doctorId}&dateStr={dateStr}",method=RequestMethod.GET)
	public ResponseParam<PatientT> findByDoctorIdHavingReminder(@PathVariable("doctorId") int doctorId,@PathVariable("dateStr") String dateStr) {

		List<PatientT> pList= pService.findByDoctorId(doctorId);
		
		Date date=null;
		try {
			date = new SimpleDateFormat("yyyy-MM-dd").parse(dateStr);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return new ResponseParam<>(1, "Date format error!");
		}
		 
		 Calendar todayCal=Calendar.getInstance();
		 	 todayCal.setTime(date);
			 todayCal.set(Calendar.HOUR_OF_DAY,0);
			 todayCal.set(Calendar.MINUTE, 0);
			 todayCal.set(Calendar.SECOND, 0);
		 
		 Calendar tomorrowCal=Calendar.getInstance();
		 	 tomorrowCal.setTime(date);
			 tomorrowCal.set(Calendar.HOUR_OF_DAY,0);
			 tomorrowCal.set(Calendar.MINUTE, 0);
			 tomorrowCal.set(Calendar.SECOND, 0);
		 	 tomorrowCal.add(Calendar.DAY_OF_MONTH, 1);
			 
		 Date today=todayCal.getTime();
		 Date tomorrow=tomorrowCal.getTime();
		 
		 List<PatientT> resultList=new ArrayList<>();
		 
		for(PatientT p:pList){
			if(hdService.findTodayRemindCount(p.getMember_id(), today, tomorrow)>0)
				resultList.add(p);
		}

		return new ResponseParam<>(resultList);
	}
	
	@ResponseBody
	@RequestMapping(path="/findByDoctorIdHavingReminderOfToday/doctorId={doctorId}",method=RequestMethod.GET)
	public ResponseParam<PatientT> findByDoctorIdHavingReminderOfToday(@PathVariable("doctorId") int doctorId) {

		List<PatientT> pList= pService.findByDoctorId(doctorId);
		
		Date date=new Date();
		 
		 Calendar todayCal=Calendar.getInstance();
		 	 todayCal.setTime(date);
			 todayCal.set(Calendar.HOUR_OF_DAY,0);
			 todayCal.set(Calendar.MINUTE, 0);
			 todayCal.set(Calendar.SECOND, 0);
		 
		 Calendar tomorrowCal=Calendar.getInstance();
		 	 tomorrowCal.setTime(date);
			 tomorrowCal.set(Calendar.HOUR_OF_DAY,0);
			 tomorrowCal.set(Calendar.MINUTE, 0);
			 tomorrowCal.set(Calendar.SECOND, 0);
		 	 tomorrowCal.add(Calendar.DAY_OF_MONTH, 1);
			 
		 Date today=todayCal.getTime();
		 Date tomorrow=tomorrowCal.getTime();
		 
		 List<PatientT> resultList=new ArrayList<>();
		 
		for(PatientT p:pList){
			if(hdService.findTodayRemindCount(p.getMember_id(), today, tomorrow)>0)
				resultList.add(p);
		}

		return new ResponseParam<>(resultList);
	}
	
	
	@ResponseBody
	@RequestMapping(path="/addPatient/memberId={memberId}&doctorId={doctorId}")
	public ResponseParam<PatientT> addPatient(@PathVariable("memberId") Integer memberId,@PathVariable("doctorId") int doctorId){
		MembersInfo mi=miService.findByMemberId(memberId);
		if(mi!=null){
			PatientT patient=new PatientT(mi.getMembersname()
					, mi.getSex()
					, mi.getBirthday()
					, mi.getId()
					, doctorId
					, mi.getTel()
					, mi.getId_type()
					, mi.getId_card()
					, ""
					, mi.getPicture()
					, mi.getBlood_type()
					, Boolean.valueOf(mi.getMarry_status()) //, mi.getMarry_status()
					, mi.getJob()
					, mi.getSocial_card()
					, mi.getAddress()
					, mi.getHome());
		
			
			pService.add(patient);
			
			ResponseParam<PatientT> resp=new ResponseParam<>();
				List<PatientT> pList=new ArrayList<>();
					pList.add(patient);
				
				resp.setData(pList);
					
			return resp;
		}else
			return new ResponseParam<>(1, "MembersInfo NOT FOUND!");
		
	}
	
	
	@ResponseBody
	@RequestMapping(path="/create",method=RequestMethod.POST)
	public ResponseParam<PatientT> create(@RequestBody PatientT patient){
		
		ResponseParam<PatientT> resp=new ResponseParam<>();
			pService.add(patient);
			List<PatientT> dList=new ArrayList<>();
				dList.add(patient);
			resp.setData(dList);
		return resp;
	}
	
	
	@ResponseBody
	@RequestMapping(path="/getProfileByMemberId/memberId={memberId}",method=RequestMethod.GET)
	public ResponseParam<PatientT> findPatientProfileByMemberId(@PathVariable("memberId") int memberId){
		MembersInfo mi=miService.findByMemberId(memberId);
		//Map<String, Object> resultMap=new HashMap<>();

		ResponseParam<PatientT> resp=new ResponseParam<>();
		
		if(mi!=null){
			
			//int age=AgeUtil.computeAgeByBirthday(mi.getBirthday());
			PatientT patient=new PatientT(mi.getMembersname()
					, mi.getSex()
					, mi.getBirthday()
					, mi.getId()
					, new Integer(0)
					, mi.getTel()
					, mi.getId_type()
					, mi.getId_card()
					, ""
					, mi.getPicture()
					, mi.getBlood_type()
					, Boolean.valueOf(mi.getMarry_status()) //, mi.getMarry_status()
					, mi.getJob()
					, mi.getSocial_card()
					, mi.getAddress()
					, mi.getHome());
			
			List<PatientT> pList=new ArrayList<PatientT>();
				pList.add(patient);
			resp.setData(pList);
			
		}else{
			resp.setCode(1);
			resp.setInfo("Not Found!");
		}
		return resp;
	}

	@ResponseBody
	@RequestMapping(path="/findPatientDetails/patientId={patientId}")
	public Map<String, Object> findPatientDetails(@PathVariable("patientId") int patientId){
		PatientT p=pService.findById(patientId);
		Map<String, Object> resultMap=new HashMap<>();
		if(p!=null){ 
			int memberId=p.getMember_id();
			
			resultMap.put("patient", p);
			
			//Dignoase Info
			
			
			//the time of lastest video 
			
			//health data
			BfData bfData=hService.findLastestBfData(memberId);
			BpData bpData=hService.findLastestBpData(memberId);
			GluData gluData=hService.findLastestGluData(memberId);
			EcgData ecgData=hService.findLastestEcgData(memberId);
			Rspo2Data rspo2Data=hService.findLastestRspo2Data(memberId);
			
			resultMap.put("bf", bfData);
			resultMap.put("gluData", gluData);
			resultMap.put("ecg", ecgData);
			resultMap.put("rspo2", rspo2Data);
			resultMap.put("bp", bpData);
			
			return resultMap;
			
		}else{
			resultMap.put("code", 1);
			resultMap.put("info", "User not exists!");
			
			return resultMap;
		}
		
		
		

	}

	
	@ResponseBody
	@RequestMapping(path="/setVideoTime",method=RequestMethod.POST,consumes="application/json")
	public ResponseParam<PatientT> setVideoTime(@RequestBody PatientT p){
		
		PatientT patient=pService.findById(p.getP_id());
		if(patient!=null){
			patient.setLastest_video_time(p.getLastest_video_time());
			pService.update(patient);
			return new ResponseParam<>();
		}else
			return new ResponseParam<>(1,"Patient Not Found!");

	}
	
	
	@ResponseBody
	@RequestMapping(path="/searchByName",method=RequestMethod.POST)
	public ResponseParam<PatientT>  searchByName(@RequestBody Map<String, String> params ){
			String value=params.get("value");
			String doctorId=params.get("doctorId");

			List<PatientT> pList=pService.searchByName(Integer.parseInt(doctorId), value);
			return new ResponseParam<>(pList);

	}
	
	@RequestMapping(path="/findWithException",method=RequestMethod.POST)
	public ResponseParam<PatientT> findWithException(@RequestBody Map<String, Object> params) throws ParseException{
		Integer doctorId=(Integer) params.get("doctorId");
		String startDateStr=(String) params.get("startDateStr");
		String endDateStr=(String)params.get("endDateStr");
		
		Date startDate=new SimpleDateFormat("yyyy-MM-dd").parse(startDateStr);
		Date endDate=new SimpleDateFormat("yyyy-MM-dd").parse(endDateStr);
		
		TodayRemindExample trExample=new TodayRemindExample();
			trExample.createCriteria().andCreate_dateBetween(startDate, endDate);
		List<TodayRemind> trList=trMapper.selectByExample(trExample);
		Set<Integer> miIdSet=new HashSet<>();
			for(TodayRemind tr:trList){
				miIdSet.add(Integer.parseInt(tr.getMember_id()));
			}
		List<Integer> miIdList=new ArrayList<>();
			miIdList.addAll(miIdSet);
		
		List<PatientT> pList=pService.findByDoctorIdAndMemberIds(doctorId, miIdList);
		
		
		return new ResponseParam<>(pList);
	}
	
	@RequestMapping(path="/findByMemberIdAndDoctorId/memberId={memberId}&doctorId={doctorId}",method=RequestMethod.GET)
	public ResponseParam<PatientT> findByMemberIdAndDoctorId(int memberId,int doctorId){
		List<PatientT> pList=pService.findByDoctorId(doctorId);
		PatientT p=pList.get(0);
		
		if(p!=null){
			List<PatientT> data=new ArrayList<>();
				data.add(p);
			return new ResponseParam<>(data);
		}else
			return new ResponseParam<>(1, "NOT FOUND!");
	}
	
	
	@RequestMapping(path="/listAllAll",method=RequestMethod.GET)
	public ResponseParam<PatientT> listAllAll(){
		List<PatientT> pList=pService.listAllAll();
		return new ResponseParam<>(pList);
	}
	
	/**
	 *  if value PATIENT:<id> change to 1, his/her doctor-list may be changed! 
	 * @param params
	 * @return
	 */
	@RequestMapping(path="/heartbeat",method=RequestMethod.POST)
	public ResponseParam<DoctorT> heartbeat(@RequestBody Map<String, Integer> params){
		Integer memberId=params.get("memberId");
		
		ValueOperations<String, String> ops=oprs.opsForValue();
		
		String val=ops.get(PATIENT_NAMESPACE+memberId);
		if(DOCTOR_LIST_UNCHANGED.equals(val)){
			log.info("value not change!");
			return new ResponseParam<>();
		}else if(DOCTOR_LIST_CHANGED.equals(val)){
			log.info("value changed");
			//re-search docotrList
			List<DoctorT> docList=docService.findByMemberId(memberId);
			ResponseParam<DoctorT> resp= new ResponseParam<>(2, "doctor-list changed");
			resp.setData(docList);
			//reset doctor-list status
			ops.set(PATIENT_NAMESPACE+memberId,DOCTOR_LIST_UNCHANGED);
			return resp;
		}else{
			return new ResponseParam<>(1, "some error! Contact developer! VALUE:"+val);
		}
		
	}
 
}
