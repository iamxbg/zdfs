package zdfs.service;

import java.util.Date;
import java.util.List;

import zdfs.model.AppointmentT;
import zdfs.model.AppointmentTExample;
import zdfs.model.AppointmentTView;

public interface IAppointmentService extends CRUDService<AppointmentT>{

	
		List<AppointmentT> findByDoctorId(int doctorId);
		
		List<AppointmentT> findByMemberIdAndDoctorId(int doctorId,int memberId);

		List<AppointmentT> findByMemberId(int memberId);
		
		List<AppointmentT> findLastestSuccess(int doctorId);
		
		List<AppointmentT> findAllAll();
		
		List<AppointmentT> findLastestSuccess(int doctorId,int memberId);
		
		List<AppointmentT> findLastestSuccessByPatientId(int patientId);

		List<AppointmentTView> findViewByMemberId(int memberId);
		
		List<AppointmentTView> findViewByDoctorId(int doctorId);
		
		List<AppointmentT> findByPatientId(int patientId);
}
