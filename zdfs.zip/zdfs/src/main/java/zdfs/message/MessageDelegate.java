package zdfs.message;

import java.io.Serializable;
import java.util.Map;

public interface MessageDelegate {

	void handleMessage(String message);

}
