package zdfs.dao;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import zdfs.model.DocAppointment;
import zdfs.model.DocAppointmentExample;

public interface DocAppointmentMapper {
    int countByExample(DocAppointmentExample example);

    int deleteByExample(DocAppointmentExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(DocAppointment record);

    int insertSelective(DocAppointment record);

    List<DocAppointment> selectByExample(DocAppointmentExample example);

    DocAppointment selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") DocAppointment record, @Param("example") DocAppointmentExample example);

    int updateByExample(@Param("record") DocAppointment record, @Param("example") DocAppointmentExample example);

    int updateByPrimaryKeySelective(DocAppointment record);

    int updateByPrimaryKey(DocAppointment record);
}