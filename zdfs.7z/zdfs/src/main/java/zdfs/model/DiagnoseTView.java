package zdfs.model;

import java.util.Date;

public class DiagnoseTView {
	
	private int id;
	private String photo;
	private String name;
	private String department_name;
	private String doctor_type_name;
	private Date create_time;
	private String info;
	private String score;
	
	
	public DiagnoseTView() {
		// TODO Auto-generated constructor stub
	}


	public DiagnoseTView(String photo, String name, String department_name, String doctor_type_name, Date create_time,
			String info, String score) {
		super();
		this.photo = photo;
		this.name = name;
		this.department_name = department_name;
		this.doctor_type_name = doctor_type_name;
		this.create_time = create_time;
		this.info = info;
		this.score = score;
	}


	public String getPhoto() {
		return photo;
	}


	public void setPhoto(String photo) {
		this.photo = photo;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}



	public String getDepartment_name() {
		return department_name;
	}


	public void setDepartment_name(String department_name) {
		this.department_name = department_name;
	}


	public String getDoctor_type_name() {
		return doctor_type_name;
	}


	public void setDoctor_type_name(String doctor_type_name) {
		this.doctor_type_name = doctor_type_name;
	}


	public Date getCreate_time() {
		return create_time;
	}


	public void setCreate_time(Date create_time) {
		this.create_time = create_time;
	}


	public String getInfo() {
		return info;
	}


	public void setInfo(String info) {
		this.info = info;
	}

	public String getScore() {
		return score;
	}


	public void setScore(String score) {
		this.score = score;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}
	
	
}
