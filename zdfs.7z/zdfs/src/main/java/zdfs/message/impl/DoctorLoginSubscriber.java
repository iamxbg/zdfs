package zdfs.message.impl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisOperations;
import org.springframework.data.redis.core.ValueOperations;
import static zdfs.message.MessageUtil.*;
import zdfs.message.IDoctorLoginSubscriber;


public class DoctorLoginSubscriber implements IDoctorLoginSubscriber{

	
	private static Logger log=LogManager.getLogger();
	
	@Autowired
	private RedisOperations<String, String> oprs;
	
	@Override
	public void handleMessage(String message, String channel) {
		// TODO Auto-generated method stub
		log.info( channel+":"+message);
		ValueOperations<String,String> ops=oprs.opsForValue();
		ops.set(DOCTOR_NAMESPACE+message, String.valueOf(1));
	}

}
