package zdfs.message.impl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisOperations;
import static zdfs.message.MessageUtil.*;

import java.util.concurrent.TimeUnit;

import zdfs.message.IDoctorHeartbeatSubscriber;

public class DoctorHeartbeatSubscriber implements IDoctorHeartbeatSubscriber {

	private static Logger log=LogManager.getLogger();
	
	@Autowired
	private RedisOperations<String, Integer> oprs;
	
	@Override
	public void handleMessage(String message, String channel) {
		// TODO Auto-generated method stub
		log.info(channel+":"+message);
		
		oprs.expire(DOCTOR_NAMESPACE+message, DOCTOR_NAMESPACE_EXPIRES_COUNT, TimeUnit.SECONDS);
		
	}

}
