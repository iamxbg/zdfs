package zdfs.service;

public interface ICRUDServiceTest{
	
	public void testAdd();
	
	public void testDeleteById();
	
	public void testSelectById();
	
	public void testSelectByExample();
	
	public void testUpdate();
}
