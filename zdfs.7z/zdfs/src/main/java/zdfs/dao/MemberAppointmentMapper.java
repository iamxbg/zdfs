package zdfs.dao;

import java.util.List;
import org.apache.ibatis.annotations.Param;
import zdfs.model.MemberAppointment;
import zdfs.model.MemberAppointmentExample;

public interface MemberAppointmentMapper {
    int countByExample(MemberAppointmentExample example);

    int deleteByExample(MemberAppointmentExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(MemberAppointment record);

    int insertSelective(MemberAppointment record);

    List<MemberAppointment> selectByExample(MemberAppointmentExample example);

    MemberAppointment selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") MemberAppointment record, @Param("example") MemberAppointmentExample example);

    int updateByExample(@Param("record") MemberAppointment record, @Param("example") MemberAppointmentExample example);

    int updateByPrimaryKeySelective(MemberAppointment record);

    int updateByPrimaryKey(MemberAppointment record);
}