package zdfs.tf02.model.view;

import java.util.List;
import java.util.Map;

public class AppointmentDateTablet {

	private String date;
	private String week;
	private boolean datestatus;
	
	private List<Map<String, Object>> data;

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getWeek() {
		return week;
	}

	public void setWeek(String week) {
		this.week = week;
	}

	public boolean isDatestatus() {
		return datestatus;
	}

	public void setDatestatus(boolean datestatus) {
		this.datestatus = datestatus;
	}

	public List<Map<String, Object>> getData() {
		return data;
	}

	public void setData(List<Map<String, Object>> data) {
		this.data = data;
	}
	
}
