package zdfs.model;

import java.util.Date;

public class DoctorTView {

   private Integer id;

   private String name;

   private String pwd;

   private String mail;

   private String tel;

   private String photo;

   private Date birthday;

   private Integer hospital_id;
   
   private String hospital_name;

   private Integer department_id;
   
   private String department_name;

   private Integer doctor_type_id;

   private String doctor_type_name;

   private String good_at;

   private Boolean online_state;

   private Boolean has_video;

   private Date create_time;

   private Boolean delflag=false;
   
   private long serve_count=0;
   
   private String aver_score;


   public Integer getId() {
       return id;
   }


   public void setId(Integer id) {
       this.id = id;
   }


   public String getName() {
       return name;
   }


   public void setName(String name) {
       this.name = name;
   }


   public String getPwd() {
       return pwd;
   }


   public void setPwd(String pwd) {
       this.pwd = pwd;
   }


   public String getMail() {
       return mail;
   }


   public void setMail(String mail) {
       this.mail = mail;
   }


   public String getTel() {
       return tel;
   }


   public void setTel(String tel) {
       this.tel = tel;
   }


   public String getPhoto() {
       return photo;
   }


   public void setPhoto(String photo) {
       this.photo = photo;
   }


   public Date getBirthday() {
       return birthday;
   }


   public void setBirthday(Date birthday) {
       this.birthday = birthday;
   }

 
   public Integer getHospital_id() {
       return hospital_id;
   }


   public void setHospital_id(Integer hospital_id) {
       this.hospital_id = hospital_id;
   }

   public Integer getDepartment_id() {
       return department_id;
   }


   public void setDepartment_id(Integer department_id) {
       this.department_id = department_id;
   }


   public Integer getDoctor_type_id() {
       return doctor_type_id;
   }


   public void setDoctor_type_id(Integer doctor_type_id) {
       this.doctor_type_id = doctor_type_id;
   }


   public String getGood_at() {
       return good_at;
   }


   public void setGood_at(String good_at) {
       this.good_at = good_at;
   }


   public Boolean getOnline_state() {
       return online_state;
   }


   public void setOnline_state(Boolean online_state) {
       this.online_state = online_state;
   }


   public Boolean getHas_video() {
       return has_video;
   }


   public void setHas_video(Boolean has_video) {
       this.has_video = has_video;
   }


   public Date getCreate_time() {
       return create_time;
   }


   public void setCreate_time(Date create_time) {
       this.create_time = create_time;
   }


   public Boolean getDelflag() {
       return delflag;
   }

   public void setDelflag(Boolean delflag) {
       this.delflag = delflag;
   }


	public String getHospital_name() {
		return hospital_name;
	}
	
	
	public void setHospital_name(String hospital_name) {
		this.hospital_name = hospital_name;
	}
	
	
	public String getDepartment_name() {
		return department_name;
	}
	
	
	public void setDepartment_name(String department_name) {
		this.department_name = department_name;
	}
	
	
	public String getDoctor_type_name() {
		return doctor_type_name;
	}
	
	
	public void setDoctor_type_name(String doctor_type_name) {
		this.doctor_type_name = doctor_type_name;
	}


	public String getAver_score() {
		return aver_score;
	}


	public void setAver_score(String aver_score) {
		this.aver_score = aver_score;
	}


	public long getServe_count() {
		return serve_count;
	}


	public void setServe_count(long serve_count) {
		this.serve_count = serve_count;
	}



	


   
}
