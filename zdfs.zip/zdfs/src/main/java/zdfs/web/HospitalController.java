package zdfs.web;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mysql.jdbc.exceptions.jdbc4.MySQLIntegrityConstraintViolationException;

import zdfs.model.AppointmentT;
import zdfs.model.DepartmentT;
import zdfs.model.DiagnoseT;
import zdfs.model.DoctorT;
import zdfs.model.HospitalT;
import zdfs.model.PatientT;
import zdfs.model.VideoT;
import zdfs.service.IAppointmentService;
import zdfs.service.IDepartmentService;
import zdfs.service.IDiagnoseService;
import zdfs.service.IDoctorService;
import zdfs.service.IPatientService;
import zdfs.service.IVideoService;
import zdfs.service.impl.HospitalService;
import zdfs.web.param.ResponseParam;

@RestController
@RequestMapping("/hospital")
public class HospitalController {

	@Autowired
	private HospitalService hService;
	@Autowired
	private IDepartmentService dService;
	@Autowired
	private IDoctorService docService;
	@Autowired
	private IVideoService videoService;
	@Autowired
	private IPatientService pService;
	@Autowired
	private IAppointmentService appService;
	@Autowired
	private IDiagnoseService diagService;
	
	
	
	
	@RequestMapping(path="/add",method=RequestMethod.POST)
	public ResponseParam<HospitalT> add(@RequestBody HospitalT hospital) throws MySQLIntegrityConstraintViolationException{
		
		
		hService.add(hospital);

		ResponseParam<HospitalT> resp=new ResponseParam<>();
		List<HospitalT> dList=new ArrayList<>();
			dList.add(hospital);
			resp.setData(dList);
		return resp;
	}
	
	
	@RequestMapping(path="/update",method=RequestMethod.POST)
	public ResponseParam<HospitalT> update(@RequestBody HospitalT hospital){
		hService.update(hospital);
		ResponseParam<HospitalT> resp=new ResponseParam<>();
			
		List<HospitalT> dList=new ArrayList<>();
			dList.add(hospital);
			
			resp.setData(dList);

		return resp;
	}
	
	@RequestMapping(path="/delete/hospitalId={hospitalId}",method=RequestMethod.POST)
	public ResponseParam<HospitalT> deleteById(@PathVariable("hospitalId") int hospitalId){

		hService.deleteById(hospitalId);
		
		return new ResponseParam<>();
		
	}
	
	@RequestMapping(path="/findById/hospitalId={hospitalId}",method=RequestMethod.GET)
	public ResponseParam<HospitalT> findById(@PathVariable("hospitalId") int hospitalId){
		HospitalT h= hService.findById(hospitalId);
		List<HospitalT> dList=new ArrayList<>();
			dList.add(h);
			
		return new ResponseParam<>(dList);
	}
	
	@RequestMapping(path="/listAll",method=RequestMethod.GET)
	public ResponseParam<HospitalT> listAll(){
		List<HospitalT> dList= hService.findAll();
		return new ResponseParam(dList);
	}
	
	
	@RequestMapping(path="/deleteAll/hospitalId={hospitalId}",method=RequestMethod.GET)
	public ResponseParam deleteAll(@PathVariable("hospitalId") Integer hospitalId){
		//List<HospitalT> hList=hService.findAll();
		HospitalT hospital=hService.findById(hospitalId);
		if(hospital!=null){
			List<DepartmentT> dList= dService.findByHospitalId(hospital.getId());
			for(DepartmentT d:dList){
				List<DoctorT> docList=docService.findByDepartment(d.getId());
				for(DoctorT doc:docList){
					//delete diagnose
					List<DiagnoseT> diagList=diagService.findByDoctorId(doc.getId());
					for(DiagnoseT diag:diagList){
						diagService.deleteById(diag.getId());
					}
					//delete videos
					List<VideoT> vList=videoService.findByDoctorId(doc.getId());
					for(VideoT v:vList){
						List<DiagnoseT> ddList=diagService.findByVideo(v.getId());
						for(DiagnoseT dd:ddList){
							diagService.deleteById(dd.getId());
						}
						videoService.deleteById(v.getId());
					}
					//delete appointment
					List<AppointmentT> appList=appService.findByDoctorId(doc.getId());
					for(AppointmentT app:appList){
						appService.deleteById(app.getId());
					}
					//delete patients
					List<PatientT> pList=pService.findByDoctorId(doc.getId());
					for(PatientT p:pList){
						List<DiagnoseT> diaggList=diagService.findByPatientId(p.getD_id());
						if(diaggList!=null){
							for(DiagnoseT diagg:diaggList){
								diagService.deleteById(diagg.getId());
							}
						}
						List<AppointmentT> apppList=appService.findByPatientId(p.getP_id());
						for(AppointmentT appp:apppList){
							appService.deleteById(appp.getId());
						}
						List<VideoT> vvList=videoService.findByPatientId(p.getP_id());
						for(VideoT vv:vvList){
							videoService.deleteById(vv.getId());
						}
						pService.deleteById(p.getP_id());
					}
					
					docService.deleteById(doc.getId());
				}
				
				dService.deleteById(d.getId());
			}
			
			hService.deleteById(hospital.getId());
		}

		
		return new ResponseParam<>(0,"OK");
	}
		
}
