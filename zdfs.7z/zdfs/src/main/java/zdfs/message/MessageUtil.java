package zdfs.message;

public class MessageUtil {

		public static final String DOCTOR_NAMESPACE="zdfs.doctor.";
		public static final String PATIENT_NAMESPACE="zdfs.patient.";
		
		public static final int DOCTOR_NAMESPACE_EXPIRES_COUNT=10;
		public static final int PATIENT_NAMESPACE_EXPIRES_COUNT=10;
		
		public static final String CHANNEL_DOCTOR_LOGIN="doctor_login";
		public static final String CHANNEL_DOCTOR_LOGOUT="doctor_logout";
		public static final String CHANNEL_DOCTOR_HEARTBEAT="doctor_heartbeat";
		
		public static final String CHANNEL_PATIENT_LOGIN="patient_login";
		public static final String CHANNEL_PATIENT_LOGOUT="patient_logout";
		public static final String CHANNEL_PATIENT_HEARTBEAT="patient_heartbeat";
		
		public static final String USER_EXISTS="1";
		public static final String USER_ABSENT="0";
		
		public static final String DOCTOR_LIST_CHANGED="1";
		public static final String DOCTOR_LIST_UNCHANGED="0";
}
