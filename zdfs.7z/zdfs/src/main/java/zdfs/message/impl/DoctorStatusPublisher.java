package zdfs.message.impl;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import zdfs.message.IDoctorStatusPublisher;
import zdfs.message.MessageUtil;

import static zdfs.message.MessageUtil.*;


public class DoctorStatusPublisher implements IDoctorStatusPublisher {

	@Autowired
	private RedisTemplate template;
	
	private static Logger log=LogManager.getLogger();
	
	@Override
	public void login(int did) {
		// TODO Auto-generated method stub
		template.convertAndSend(CHANNEL_DOCTOR_LOGIN, String.valueOf(did));
	}

	@Override
	public void logout(int did) {
		// TODO Auto-generated method stub

		template.convertAndSend(CHANNEL_DOCTOR_LOGOUT, String.valueOf(did));
	}

	@Override
	public void heartBeat(int did) {
		// TODO Auto-generated method stub
		log.info("@pushlish- doctorId:"+did);
		template.convertAndSend(CHANNEL_DOCTOR_HEARTBEAT, String.valueOf(did));

	}

}
