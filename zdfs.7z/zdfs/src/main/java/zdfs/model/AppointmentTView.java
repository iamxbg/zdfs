package zdfs.model;

import java.util.Date;

public class AppointmentTView {

	    private Long id;


	    private Integer p_id;


	    private Integer d_id;

	    private String tel;


	    private String info;

	    private Date appoint_date;
	    

	    private Date appoint_time_start;


	    private Date appoint_time_end;


	    private Integer state;


	    private Integer refuse_reason;

	    private Date create_time;


	    private Boolean delflag=false;


	    private Boolean embark_direction;
	    


		private String doctor_name;
		private String doctor_photo;
		private String department_name;
		private String hospital_name;
		private String doctor_type_name;

 
		private String patient_photo;
		private String patient_name;
		private Boolean patient_sex;
		private int patient_age;
		private Date patient_birthday;

	    public Long getId() {
	        return id;
	    }


	    public void setId(Long id) {
	        this.id = id;
	    }


	    public Integer getP_id() {
	        return p_id;
	    }


	    public void setP_id(Integer p_id) {
	        this.p_id = p_id;
	    }


	    public Integer getD_id() {
	        return d_id;
	    }


	    public void setD_id(Integer d_id) {
	        this.d_id = d_id;
	    }


	    public String getTel() {
	        return tel;
	    }


	    public void setTel(String tel) {
	        this.tel = tel;
	    }


	    public String getInfo() {
	        return info;
	    }


	    public void setInfo(String info) {
	        this.info = info;
	    }


	    public Date getAppoint_date() {
	        return appoint_date;
	    }


	    public void setAppoint_date(Date appoint_date) {
	        this.appoint_date = appoint_date;
	    }


	    public Date getAppoint_time_start() {
	        return appoint_time_start;
	    }


	    public void setAppoint_time_start(Date appoint_time_start) {
	        this.appoint_time_start = appoint_time_start;
	    }


	    public Date getAppoint_time_end() {
	        return appoint_time_end;
	    }


	    public void setAppoint_time_end(Date appoint_time_end) {
	        this.appoint_time_end = appoint_time_end;
	    }


	    public Integer getState() {
	        return state;
	    }


	    public void setState(Integer state) {
	        this.state = state;
	    }


	    public Integer getRefuse_reason() {
	        return refuse_reason;
	    }


	    public void setRefuse_reason(Integer refuse_reason) {
	        this.refuse_reason = refuse_reason;
	    }


	    public Date getCreate_time() {
	        return create_time;
	    }


	    public void setCreate_time(Date create_time) {
	        this.create_time = create_time;
	    }


	    public Boolean getDelflag() {
	        return delflag;
	    }


	    public void setDelflag(Boolean delflag) {
	        this.delflag = delflag;
	    }


	    public Boolean getEmbark_direction() {
	        return embark_direction;
	    }


	    public void setEmbark_direction(Boolean embark_direction) {
	        this.embark_direction = embark_direction;
	    }


		public String getDoctor_name() {
			return doctor_name;
		}


		public void setDoctor_name(String doctor_name) {
			this.doctor_name = doctor_name;
		}





		public String getDoctor_photo() {
			return doctor_photo;
		}


		public void setDoctor_photo(String doctor_photo) {
			this.doctor_photo = doctor_photo;
		}


		public String getDepartment_name() {
			return department_name;
		}


		public void setDepartment_name(String department_name) {
			this.department_name = department_name;
		}


		public String getHospital_name() {
			return hospital_name;
		}


		public void setHospital_name(String hospital_name) {
			this.hospital_name = hospital_name;
		}


		public String getDoctor_type_name() {
			return doctor_type_name;
		}


		public void setDoctor_type_name(String doctor_type_name) {
			this.doctor_type_name = doctor_type_name;
		}


		public String getPatient_photo() {
			return patient_photo;
		}


		public void setPatient_photo(String patient_photo) {
			this.patient_photo = patient_photo;
		}


		public String getPatient_name() {
			return patient_name;
		}


		public void setPatient_name(String patient_name) {
			this.patient_name = patient_name;
		}




		public Boolean getPatient_sex() {
			return patient_sex;
		}


		public void setPatient_sex(Boolean patient_sex) {
			this.patient_sex = patient_sex;
		}


		public int getPatient_age() {
			return patient_age;
		}


		public void setPatient_age(int patient_age) {
			this.patient_age = patient_age;
		}


		public Date getPatient_birthday() {
			return patient_birthday;
		}


		public void setPatient_birthday(Date patient_birthday) {
			this.patient_birthday = patient_birthday;
		}



}
