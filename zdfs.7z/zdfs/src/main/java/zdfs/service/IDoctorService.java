package zdfs.service;

import java.util.List;

import zdfs.model.DoctorT;
import zdfs.model.DoctorTExample;
import zdfs.model.DoctorTView;

public interface IDoctorService extends CRUDService<DoctorT>{

	public List<DoctorT> findByNameLike(String name);
	
	public List<DoctorT> findByTelAndPwd(String tel,String pwd);
	
	public List<DoctorT> findByHospitalId(int hospitalId);
	
	public List<DoctorT> findByHospitalIdAndDepartmentId(int hospitalId,int departmentId);
	
	public List<DoctorT> findByTel(String tel);
	
	public List<DoctorTView> findByHospitalId2(int hospitalId);
	
	public List<DoctorTView> findByHospitalIdAndDepartmentId2(int hospitalId,int departmentId);
	
	public List<DoctorT> listAllAll();
	
	public List<DoctorTView> selectByTel(String tel);
	
	public List<DoctorT> findByDepartment(int departmentId);
	
	public List<DoctorT> findByMemberId(int memberId);
	

}
