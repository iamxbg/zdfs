package zdfs.service.impl;

import java.io.Serializable;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;

import zdfs.dao.VideoTMapper;
import zdfs.model.VideoT;
import zdfs.model.VideoTExample;
import zdfs.model.VideoTExample.Criteria;
import zdfs.model.view.VideoTView;
import zdfs.service.IVideoService;

@Service
@Transactional
public class VideoService implements IVideoService{

	@Autowired
	private VideoTMapper mapper;
	
	@Override
	public Serializable add(VideoT t) {
		// TODO Auto-generated method stub
		return mapper.insert(t);
	}

	@Override
	public int deleteById(Serializable id) {
		// TODO Auto-generated method stub
		return mapper.deleteByPrimaryKey((Integer)id);
	}

	@Override
	public int update(VideoT t) {
		// TODO Auto-generated method stub
		return mapper.updateByPrimaryKey(t);
	}

	@Override
	public VideoT findById(Serializable id) {
		// TODO Auto-generated method stub
		return mapper.selectByPrimaryKey((Integer)id);
	}

	@Override
	public int setScore(Integer score, Integer id) {
		// TODO Auto-generated method stub
		VideoT v=mapper.selectByPrimaryKey(id);
		if(v==null) return -1;
		else{
			v.setScore(score);
			mapper.updateByPrimaryKey(v);
			return 1;
		} 
	}

	@Override
	public Float selectAverScore(Integer d_id) {
		// TODO Auto-generated method stub
		return mapper.selectAverScore(d_id);

	}

	@Override
	public Long findCount(Integer d_id) {
		// TODO Auto-generated method stub
		VideoTExample example=new VideoTExample();
			example.createCriteria().andD_idEqualTo(d_id);
			
		return mapper.countByExample(example);
	}
	

	public List<VideoT> listAllAll(){
		VideoTExample example=new VideoTExample();
			
		return mapper.selectByExample(example);
	}

	@Override
	public List<VideoT> findByDoctorId(int doctorId) {
		// TODO Auto-generated method stub
		VideoTExample example=new VideoTExample();
			Criteria cri=example.createCriteria().andD_idEqualTo(doctorId);
				example.setOrderByClause("create_time desc");
					
		return mapper.selectByExample(example);
	}

	@Override
	public List<VideoT> findByPatientId(int patientId) {
		// TODO Auto-generated method stub
		VideoTExample example=new VideoTExample();
			Criteria cri=example.createCriteria();
				cri.andP_idEqualTo(patientId);
				example.setOrderByClause("create_time desc");
		return mapper.selectByExample(example);
	}

	@Override
	public List<VideoT> findByDoctorIdAndMemberId(int doctorId, int memberId) {
		// TODO Auto-generated method stub
		return mapper.findByDoctorIdAndMemberId(doctorId, memberId);
	}

	@Override
	public List<VideoT> findByMemberId(int memberId) {
		// TODO Auto-generated method stub
		return mapper.findByMemberId(memberId);
	}

	@Override
	public List<VideoTView> findViewByMemberId(int memberId) {
		// TODO Auto-generated method stub
		return mapper.findViewByMemberId(memberId);
	}

}
