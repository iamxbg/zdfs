package zdfs.message.impl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import zdfs.message.IDoctorExpireSubscriber;

public class DoctorExpireSubscriber implements IDoctorExpireSubscriber{

	private static Logger log=LogManager.getLogger();
	
	@Override
	public void handleMessage(String message, String channel) {
		// TODO Auto-generated method stub
		log.info(channel+":"+message);
	}

}
