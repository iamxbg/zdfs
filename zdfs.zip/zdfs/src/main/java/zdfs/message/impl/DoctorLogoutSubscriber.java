package zdfs.message.impl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisOperations;
import org.springframework.data.redis.core.ValueOperations;
import static zdfs.message.MessageUtil.*;
import java.util.List;
import java.util.concurrent.TimeUnit;
import zdfs.message.IDoctorStatusSubscriber;
import zdfs.model.PatientT;
import zdfs.service.IPatientService;
import zdfs.service.impl.PatientService;

public class DoctorLogoutSubscriber implements IDoctorStatusSubscriber{

	private static Logger log=LogManager.getLogger();
	
	@Autowired
	private RedisOperations<String, String> oprs;
	@Autowired
	private IPatientService pService;
	
	@Override
	public void handleMessage(String message, String channel) {
		// TODO Auto-generated method stub
		
		log.info(channel+":"+message);
		oprs.expire(DOCTOR_NAMESPACE+message, 0, TimeUnit.SECONDS);
	
		
	}

}
