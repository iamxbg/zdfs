package zdfs.message.impl;

import static zdfs.message.MessageUtil.DOCTOR_LIST_CHANGED;
import static zdfs.message.MessageUtil.PATIENT_NAMESPACE;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisOperations;
import org.springframework.data.redis.core.ValueOperations;

import zdfs.message.IDoctorStatusSubscriber;
import zdfs.model.PatientT;
import zdfs.service.IPatientService;


public class DoctorExpireSubscriber implements IDoctorStatusSubscriber{

	private static Logger log=LogManager.getLogger();
	
	@Autowired
	private IPatientService pService;
	@Autowired
	private RedisOperations<String, String> oprs;
	
	@Override
	public void handleMessage(String message, String channel) {
		// TODO Auto-generated method stub
		log.info(channel+":"+message);
		
		//notify all user -- change user's status
		ValueOperations<String, String> valOps=oprs.opsForValue();
		HashOperations<String,String,Integer> hashOps=oprs.opsForHash();
		
		List<PatientT> pList=pService.findByDoctorId(Integer.parseInt(message));
		for(PatientT p:pList){
			String pKey=PATIENT_NAMESPACE+p.getMember_id();
			if(oprs.hasKey(pKey)){
				hashOps.put(pKey, message, 0);
			}
		}
	}

}
