package zdfs.service;

import java.util.List;

import zdfs.model.VideoT;
import zdfs.model.view.VideoTView;

public interface IVideoService extends CRUDService<VideoT>{

	
	public int setScore(Integer score,Integer id);
	
	public Float selectAverScore(Integer d_id);
	
	public Long findCount(Integer d_id);
	
	public List<VideoT> listAllAll();
	
	public List<VideoT> findByDoctorId(int doctorId);
	
	public List<VideoT> findByPatientId(int patientId);
	
	public List<VideoT> findByDoctorIdAndMemberId(int doctorId,int memberId);
	
	
	public List<VideoT> findByMemberId(int memberId);
	
	public List<VideoTView> findViewByMemberId(int memberId);
}
