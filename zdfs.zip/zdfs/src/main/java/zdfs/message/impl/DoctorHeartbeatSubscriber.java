package zdfs.message.impl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisOperations;
import org.springframework.data.redis.core.ValueOperations;

import zdfs.message.IDoctorStatusSubscriber;
import zdfs.model.PatientT;
import zdfs.service.IDoctorService;
import zdfs.service.IPatientService;

import static zdfs.message.MessageUtil.*;

import java.util.List;
import java.util.concurrent.TimeUnit;


public class DoctorHeartbeatSubscriber implements IDoctorStatusSubscriber {

	private static Logger log=LogManager.getLogger();
	
	@Autowired
	private RedisOperations<String, String> oprs;
	@Autowired
	private IPatientService pService;
	
	@Override
	public void handleMessage(String message, String channel) {
		// TODO Auto-generated method stub
		log.info(channel+":"+message);
		ValueOperations<String, String> valOps=oprs.opsForValue();
		HashOperations<String, String, Object> hashOps=oprs.opsForHash();
		
		if(oprs.hasKey(DOCTOR_NAMESPACE+message))
			oprs.expire(DOCTOR_NAMESPACE+message, DOCTOR_NAMESPACE_EXPIRES_COUNT, TimeUnit.SECONDS);
		else{	
			valOps.set(DOCTOR_NAMESPACE+message, String.valueOf(1),DOCTOR_NAMESPACE_EXPIRES_COUNT, TimeUnit.SECONDS);
			
			List<PatientT> pList=pService.findByDoctorId(Integer.parseInt(message));
			for(PatientT p:pList){
				String pKey=PATIENT_NAMESPACE+p.getMember_id();
				if(oprs.hasKey(pKey)){
					hashOps.put(pKey, message, 1);
				}
			}
		}
			
	}

}
