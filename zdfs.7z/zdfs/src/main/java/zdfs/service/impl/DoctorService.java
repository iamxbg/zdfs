package zdfs.service.impl;

import java.io.Serializable;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisOperations;
import org.springframework.stereotype.Service;

import zdfs.dao.DoctorTMapper;
import zdfs.message.MessageUtil;
import zdfs.model.DoctorT;
import zdfs.model.DoctorTExample;
import zdfs.model.DoctorTView;
import zdfs.service.IDoctorService;

@Service
@org.springframework.transaction.annotation.Transactional
public class DoctorService implements IDoctorService {

	@Autowired
	private DoctorTMapper mapper;


	@Override
	public Serializable add(DoctorT t) {
		// TODO Auto-generated method stub
		return mapper.insert(t);
	}

	@Override
	public int deleteById(Serializable id) {
		// TODO Auto-generated method stub
		return mapper.deleteByPrimaryKey((int)id);
	}

	@Override
	public int update(DoctorT t) {
		// TODO Auto-generated method stub
		return mapper.updateByPrimaryKey(t);
	}

	@Override
	public DoctorT findById(Serializable id) {
		// TODO Auto-generated method stub
		return mapper.selectByPrimaryKey((int)id);
	}

	@Override
	public List<DoctorT> findByNameLike(String name) {
		// TODO Auto-generated method stub
		DoctorTExample example=new DoctorTExample();
			example.createCriteria().andNameLike("%"+name+"%");
			example.setOrderByClause("id");
		return mapper.selectByExample(example);
	}

	@Override
	public List<DoctorT> findByTelAndPwd(String tel, String pwd) {
		// TODO Auto-generated method stub
		DoctorTExample example=new DoctorTExample();
			example.createCriteria().andTelEqualTo(tel)
								.andDelflagEqualTo(false)
								.andPwdEqualTo(pwd);
			
		return mapper.selectByExample(example);
	}

	@Override
	public List<DoctorT> findByHospitalId(int hospitalId) {
		// TODO Auto-generated method stub
		DoctorTExample example=new DoctorTExample();
			example.createCriteria().andHospital_idEqualTo(hospitalId)
									.andDelflagEqualTo(false);
			example.setOrderByClause("id");
		return mapper.selectByExample(example);
	}

	@Override
	public List<DoctorT> findByHospitalIdAndDepartmentId(int hospitalId, int departmentId) {
		// TODO Auto-generated method stub
		DoctorTExample example=new DoctorTExample();
			example.createCriteria().andDelflagEqualTo(false)
									.andHospital_idEqualTo(hospitalId)
									.andDepartment_idEqualTo(departmentId);
			example.setOrderByClause("id");
		return mapper.selectByExample(example);
	}

	@Override
	public List<DoctorT> findByTel(String tel){
		DoctorTExample example=new DoctorTExample();
			example.createCriteria().andDelflagEqualTo(false)
									.andTelEqualTo(tel);
			
			example.setOrderByClause("id");
			
			return mapper.selectByExample(example);
			
	}

	@Override
	public List<DoctorTView> findByHospitalId2(int hospitalId) {
		// TODO Auto-generated method stub
		return mapper.findByHospitalId(hospitalId);
	}

	@Override
	public List<DoctorTView> findByHospitalIdAndDepartmentId2(int hospitalId, int departmentId) {
		// TODO Auto-generated method stub
		return mapper.findByHospitalIdAndDepartmentId(hospitalId, departmentId);
	}

	@Override
	public List<DoctorT> listAllAll() {
		// TODO Auto-generated method stub
		DoctorTExample example=new DoctorTExample();
			
		return mapper.selectByExample(example);
	}

	@Override
	public List<DoctorTView> selectByTel(String tel) {
		// TODO Auto-generated method stub
		return mapper.selectByTel(tel);
	}

	@Override
	public List<DoctorT> findByDepartment(int departmentId) {
		// TODO Auto-generated method stub
		DoctorTExample example=new DoctorTExample();
			example.createCriteria()
					.andDepartment_idEqualTo(departmentId);
		return mapper.selectByExample(example);
	}

	@Override
	public List<DoctorT> findByMemberId(int memberId) {
		// TODO Auto-generated method stub
		return mapper.findByMemberId(memberId);
	}




	
	


}
