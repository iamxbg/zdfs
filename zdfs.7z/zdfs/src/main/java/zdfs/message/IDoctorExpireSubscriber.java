package zdfs.message;

public interface IDoctorExpireSubscriber   {

	void handleMessage(String message,String channel);
	
}
