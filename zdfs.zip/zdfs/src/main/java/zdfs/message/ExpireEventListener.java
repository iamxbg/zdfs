package zdfs.message;

import redis.clients.jedis.JedisPubSub;

public class ExpireEventListener extends JedisPubSub{

	public ExpireEventListener() {
		// TODO Auto-generated constructor stub
	}

}
