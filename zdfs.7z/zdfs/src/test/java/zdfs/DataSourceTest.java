package zdfs;

import static org.junit.Assert.assertNotNull;

import java.sql.SQLException;
import java.util.Calendar;
import java.util.Date;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Assert;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import zdfs.util.AgeUtil;

//@Ignore
@RunWith(JUnit4.class)
//@ContextConfiguration(locations={"classpath:applicationContext.xml"})
public class DataSourceTest {

	@Resource(name="dataSource")
	private DataSource dataSource;
	@Resource(name="tf02_dataSource")
	private DataSource tf02_dataSource;
	
	private static Logger log=LogManager.getLogger();
	
	public DataSourceTest() {
		// TODO Auto-generated constructor stub
	}
	
	//@Test
	public void testDataSourceNotNull() throws SQLException{
		
		Assert.assertNotNull(dataSource);
		Assert.assertNotNull(tf02_dataSource);
		
		Assert.assertNotNull(dataSource.getConnection());
		Assert.assertNotNull(tf02_dataSource.getConnection());
		
		
	}

	
	//@Test
	public void testTF02DataSourceNotNull(){
		Calendar cal=Calendar.getInstance();
			cal.setTime(new Date(744220800000l));
			
			int year=cal.get(Calendar.YEAR);
			
			System.out.println("year:"+year);
			
			System.out.println(AgeUtil.computeAgeByBirthday(new Date(744220800000l)));
	}
	
	@Test
	public void test(){
		String aver_score="4.34";
		System.out.println(aver_score.toString().substring(aver_score.toString().indexOf('.')+1));
	}
	
}
