package zdfs.model.view;

import java.util.List;

import zdfs.model.DiagnoseT;
import zdfs.model.VideoT;

public class VideoTView extends VideoT {
	
	
	private String hospital_name;
	private String department_name;
	private String doctor_photo;
	private String doctor_name;
	private String doctor_type_name;
	
	private List<DiagnoseT> diagnoseList;
	
	public VideoTView() {
		// TODO Auto-generated constructor stub
	}

	public String getHospital_name() {
		return hospital_name;
	}

	public void setHospital_name(String hospital_name) {
		this.hospital_name = hospital_name;
	}

	public String getDepartment_name() {
		return department_name;
	}

	public void setDepartment_name(String department_name) {
		this.department_name = department_name;
	}

	public String getDoctor_photo() {
		return doctor_photo;
	}

	public void setDoctor_photo(String doctor_photo) {
		this.doctor_photo = doctor_photo;
	}

	public String getDoctor_name() {
		return doctor_name;
	}

	public void setDoctor_name(String doctor_name) {
		this.doctor_name = doctor_name;
	}

	public String getDoctor_type_name() {
		return doctor_type_name;
	}

	public void setDoctor_type_name(String doctor_type_name) {
		this.doctor_type_name = doctor_type_name;
	}


}
