package zdfs.web;

import java.util.ArrayList;
import java.util.Date;
import java.util.Formatter.BigDecimalLayoutForm;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import zdfs.model.DiagnoseTView;
import zdfs.model.DoctorT;
import zdfs.model.PatientT;
import zdfs.model.VideoT;
import zdfs.model.view.VideoTView;
import zdfs.service.IDiagnoseService;
import zdfs.service.IPatientService;
import zdfs.service.impl.DoctorService;
import zdfs.service.impl.VideoService;
import zdfs.web.param.ResponseParam;

@RestController
@RequestMapping(path="/video")
public class VideoController {

	@Autowired
	private VideoService service;
	
	@Autowired
	private DoctorService docService;
	@Autowired
	private IPatientService pService;
	
	@Autowired
	private IDiagnoseService diagService;
	
	@RequestMapping(path="/setScore",method=RequestMethod.POST)
	public ResponseParam<VideoT> setVideoScore(@RequestBody VideoT video){
		
		if(service.setScore(video.getScore(),video.getId())==1){
			
			//reset doctor's aver_score
			int d_id=video.getD_id();
			DoctorT doctorT=docService.findById(d_id);
			
			Float aver_score=service.selectAverScore(d_id);
			
			if(aver_score!=null){
				doctorT.setAver_score(aver_score.toString().substring(0,aver_score.toString().indexOf('.')+2) );
				
				docService.update(doctorT);
			}

			List<VideoT> data=new ArrayList<>(); 
			return new ResponseParam<>(data);
			
		}else
			return new ResponseParam<>(1, "Video not found!");
		
	}
	

	//@RequestMapping(path="/upload",method=RequestMethod.POST,consumes="application/json")
	public ResponseParam<VideoT> uploadVideo(@RequestBody VideoT video){
			service.add(video);
			List<VideoT> dataList=new ArrayList<>();
			dataList.add(video);
			
			DoctorT doctor=docService.findById(video.getD_id());
			doctor.setServe_count(doctor.getServe_count()+1);
			docService.update(doctor);
			
			PatientT patient=pService.findById(video.getP_id());
			patient.setLastest_video_time(new Date());
			pService.update(patient);
			
			
		return new ResponseParam<>(dataList);
	}
	
	
	@RequestMapping(path="/listAllAll",method=RequestMethod.GET)
	public ResponseParam<VideoT> listAllAll(){
		return new ResponseParam<>(service.listAllAll());
	}
	
	@RequestMapping(path="/findByDoctorId/doctorId={doctorId}",method=RequestMethod.GET)
	public ResponseParam<VideoT> findByDoctorId(@PathVariable("doctorId") Integer doctorId){
		return new ResponseParam<>(service.findByDoctorId(doctorId));
	}
	
	@RequestMapping(path="/findByPatientId/patientId={patientId}",method=RequestMethod.GET)
	public ResponseParam<VideoT> findByPatientId(@PathVariable("patientId") Integer patientId){
		return new ResponseParam<>(service.findByPatientId(patientId));
	}
	
	@RequestMapping(path="/findByDoctorIdAndMemberId/doctorId={doctorId}&memberId={memberId}",method=RequestMethod.GET)
	public ResponseParam<VideoT> findByDoctorIdAndPatientId(@PathVariable("doctorId") Integer doctorId,@PathVariable("memberId") Integer memberId){
		return new ResponseParam<>(service.findByDoctorIdAndMemberId(doctorId, memberId));
	}
	
	@RequestMapping(path="/findByMemberId/memberId={memberId}",method=RequestMethod.GET)
	public ResponseParam<VideoT> findByMemberId(@PathVariable("memberId") Integer memberId){
		List<VideoT> vList=service.findByMemberId(memberId);
		
		for(VideoT v:vList){
			int videoId=v.getId();
			List<DiagnoseTView> diagnoseTViews=diagService.findViewByMemberIdAndVideoId(memberId, videoId);
			v.setDiagnoseList(diagnoseTViews);
		}
		
			return new ResponseParam<>(vList);
	}
	
	@RequestMapping(path="/findViewByMemberId/memberId={memberId}",method=RequestMethod.GET)
	public ResponseParam<VideoTView> findViewByMemberId(@PathVariable("memberId") Integer memberId){
		List<VideoTView> vList=service.findViewByMemberId(memberId);
		
		for(VideoTView v:vList){
			int videoId=v.getId();
			List<DiagnoseTView> diagList=diagService.findViewByMemberIdAndVideoId(memberId, videoId);
			v.setDiagnoseList(diagList);
		}
		
		return new ResponseParam<>(vList);
	}
	
	@RequestMapping(path="/addVideo/memberId={memberId}",method=RequestMethod.POST)
	public ResponseParam<VideoT> addVideo(@PathVariable("memberId") Integer memberId,@RequestBody VideoT video){
		List<PatientT> pList=pService.findByDoctorIdAndMemberId(video.getD_id(), memberId);
		if(pList!=null && pList.size()==1){
			
			PatientT p=pList.get(0);
			
			video.setP_id(p.getP_id());
			video.setCreate_time(new Date());
			service.add(video);
			
			p.setLastest_video_time(new Date());
			pService.update(p);
			
			DoctorT doctor=docService.findById(video.getD_id());	
			doctor.setServe_count(doctor.getServe_count()==null?0:doctor.getServe_count()+1);
			docService.update(doctor);
			

			List<VideoT> vList=new ArrayList<>();
				vList.add(video);
			
			return new ResponseParam<>(vList);
		}else{
			return new ResponseParam<>(1, "Patient not found!");
		}
			
	}
}
