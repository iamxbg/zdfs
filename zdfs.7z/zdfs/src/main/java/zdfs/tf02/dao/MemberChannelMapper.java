package zdfs.tf02.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import zdfs.tf02.model.MemberChannel;
import zdfs.tf02.model.MemberChannelExample;

public interface MemberChannelMapper {
	int countByExample(MemberChannelExample example);

	int deleteByExample(MemberChannelExample example);

	int deleteByPrimaryKey(Integer id);

	int insert(MemberChannel record);

	int insertSelective(MemberChannel record);

	List<MemberChannel> selectByExample(MemberChannelExample example);

	MemberChannel selectByPrimaryKey(Integer id);

	int updateByExampleSelective(@Param("record") MemberChannel record,
			@Param("example") MemberChannelExample example);

	int updateByExample(@Param("record") MemberChannel record,
			@Param("example") MemberChannelExample example);

	int updateByPrimaryKeySelective(MemberChannel record);

	int updateByPrimaryKey(MemberChannel record);
}