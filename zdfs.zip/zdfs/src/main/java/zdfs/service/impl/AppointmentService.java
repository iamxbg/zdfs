package zdfs.service.impl;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import zdfs.dao.AppointmentTMapper;
import zdfs.model.AppointmentT;
import zdfs.model.AppointmentTExample;
import zdfs.model.AppointmentTView;
import zdfs.service.IAppointmentService;

@Service
@Transactional
public class AppointmentService implements IAppointmentService {

	@Autowired
	private AppointmentTMapper mapper;
	
	public AppointmentService() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public Serializable add(AppointmentT t) {
		// TODO Auto-generated method stub
		return mapper.insert(t);
	}

	@Override
	public int deleteById(Serializable id) {
		// TODO Auto-generated method stub
		return mapper.deleteByPrimaryKey((long)id);
	}

	@Override
	public int update(AppointmentT t) {
		// TODO Auto-generated method stub
		return mapper.updateByPrimaryKey(t);
	}

	@Override
	public AppointmentT findById(Serializable id) {
		// TODO Auto-generated method stub
		return mapper.selectByPrimaryKey((long)id);
	}

	@Override
	public List<AppointmentT> findByDoctorId(int doctorId) {
		// TODO Auto-generated method stub
		AppointmentTExample example=new AppointmentTExample();
			example.createCriteria().andDelflagEqualTo(false)
									.andD_idEqualTo(doctorId)
									.andEmbark_directionEqualTo(false);
									
			example.setOrderByClause("appoint_date");
		return mapper.selectByExample(example);
	}

	@Override
	public List<AppointmentT> findByMemberIdAndDoctorId(int doctorId, int patientId) {
		// TODO Auto-generated method stub
		AppointmentTExample example=new AppointmentTExample();
			example.createCriteria().andDelflagEqualTo(false)
									.andP_idEqualTo(patientId);
			
			example.setOrderByClause("appoint_date");
			
		return mapper.selectByExample(example);
	}

	@Override
	public List<AppointmentT> findByMemberId(int memberId) {
		// TODO Auto-generated method stub
		return mapper.findByMemberId(memberId);
	}

	@Override
	public List<AppointmentT> findLastestSuccess(int doctorId) {
		// TODO Auto-generated method stub
		return mapper.findLastestSuccess(doctorId);
	}

	@Override
	public List<AppointmentT> findAllAll() {
		// TODO Auto-generated method stub
		return mapper.selectByExample(new AppointmentTExample());
	}

	@Override
	public List<AppointmentT> findLastestSuccess(int doctorId, int memberId) {
		// TODO Auto-generated method stub
		return mapper.findLastestSuccessByMemberIdAndDoctorId(memberId, doctorId);
	}

	@Override
	public List<AppointmentT> findLastestSuccessByPatientId(int patientId) {
		// TODO Auto-generated method stub
		return mapper.findLastestSuccessByPatientId(patientId);
	}

	@Override
	public List<AppointmentTView> findViewByMemberId(int memberId) {
		// TODO Auto-generated method stub
		return mapper.findViewByMemberId(memberId);
	}

	@Override
	public List<AppointmentTView> findViewByDoctorId(int doctorId) {
		// TODO Auto-generated method stub
		return mapper.findViewByDoctorId(doctorId);
	}

	@Override
	public List<AppointmentT> findByPatientId(int patientId) {
		// TODO Auto-generated method stub
		AppointmentTExample example=new AppointmentTExample();
			example.createCriteria().andP_idEqualTo(patientId);
			return mapper.selectByExample(example);
	}


	

}
