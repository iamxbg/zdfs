package zdfs.message;

public interface IDoctorStatusSubscriber {

	public void handleMessage(String message, String channel);
	
}
