package zdfs.message;

public interface IDoctorHeartbeatSubscriber {

	void handleMessage(String message,String channel);
}
