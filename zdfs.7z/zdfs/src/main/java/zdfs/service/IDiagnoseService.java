package zdfs.service;

import java.util.Date;
import java.util.List;

import zdfs.model.DiagnoseT;
import zdfs.model.DiagnoseTExample;
import zdfs.model.DiagnoseTView;

public interface IDiagnoseService extends CRUDService<DiagnoseT>{
	
	public List<DiagnoseT> findByPatientIdAndDoctorId(int patientId,int doctorId);
	
	public List<DiagnoseT> findByDoctorIdAndDate(int doctorId,Date date);
	
	public List<DiagnoseT> findByPatientId(int patientId);
	
	public List<DiagnoseT> findByPatientIdAndDate(int patientId,Date date);
	
	//public List<DiagnoseT> findByMemberId(int memberId);
	
	public List<DiagnoseT> listAllAll();
	
	public List<DiagnoseTView> findViewByMemberId(int memberId);
	
	public List<DiagnoseT> findByDoctorId(int doctorId);
}
