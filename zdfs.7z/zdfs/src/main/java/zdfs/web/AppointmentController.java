package zdfs.web;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import zdfs.model.AppointmentT;
import zdfs.model.AppointmentTExample;
import zdfs.model.AppointmentTView;
import zdfs.model.PatientT;
import zdfs.service.IAppointmentService;
import zdfs.service.IPatientService;
import zdfs.service.impl.AppointmentService;
import zdfs.tf02.model.MembersInfo;
import zdfs.tf02.model.view.AppointmentDateTablet;
import zdfs.tf02.service.IMembersInfoService;
import zdfs.util.AgeUtil;
import zdfs.web.param.ResponseParam;

@RestController
@RequestMapping(path="/appointment")
public class AppointmentController {

	@Autowired
	private IAppointmentService service;
	
	@Autowired
	private IMembersInfoService miService;
	@Autowired
	private IPatientService pService;
	
	private static Logger log=LogManager.getLogger();
	
	public AppointmentController() {
		// TODO Auto-generated constructor stub
	}

	
	@RequestMapping(path="/embark")
	public ResponseParam<AppointmentT> embark(@RequestBody AppointmentT appointment){
		
		log.info("date:"+appointment.getAppoint_date().getTime());
		log.info("start_time:"+appointment.getAppoint_time_start());
		log.info("end_time:"+appointment.getAppoint_time_end());
		
		appointment.setDelflag(false);
		appointment.setRefuse_reason(0);
		service.add(appointment);
		return new ResponseParam<>();

	}
	

	@RequestMapping(path="/findByDoctorId/doctorId={doctorId}")
	public ResponseParam<AppointmentT> findByDoctorId(@PathVariable("doctorId") int doctorId){
		List<AppointmentT> aList=service.findByDoctorId(doctorId);
		return new ResponseParam<>(aList);
	}
	
	@Deprecated
	//@RequestMapping(path="/handleAppointment")
	public ResponseParam<AppointmentT> handleAppointment(@RequestBody AppointmentT appointment){
		service.update(appointment);
		List<AppointmentT> aList=new ArrayList<>();
			aList.add(appointment);
		return new ResponseParam<>(aList);
	}
	

	@RequestMapping(path="/findByMemberId/memberId={memberId}",method=RequestMethod.GET)
	public ResponseParam<AppointmentT> findByMemberId(@PathVariable("memberId") Integer memberId){
		
		List<AppointmentT> dataList =service.findByMemberId(memberId);
		
		ResponseParam<AppointmentT> resp=new ResponseParam<>();
			resp.setData(dataList);
			
			return resp;
	}
	
	@Deprecated
	//@RequestMapping(path="/findLastestHandle/doctorId={doctorId}",method=RequestMethod.GET)
	public ResponseParam<AppointmentT> findLastestSuccess(@PathVariable("doctorId") Integer doctorId){
		List<AppointmentT> dataList=service.findLastestSuccess(doctorId);
		return new ResponseParam<>(dataList);
	}
	
	@Deprecated
	//@RequestMapping(path="/findLastestHandle")
	public ResponseParam<AppointmentT> findLastestHandle(@RequestBody Map<String, Object> params){
		if(params.containsKey("patientId")){
			
			Integer patientId=(Integer) params.get("patientId");
			return new ResponseParam<>(service.findLastestSuccessByPatientId(patientId));
		}else if(params.containsKey("doctorId") && params.containsKey("memberId")){
			Integer doctorId=(Integer) params.get("doctorId");
			Integer memberId=(Integer) params.get("memberId");
			
			return new ResponseParam<>(service.findLastestSuccess(doctorId, memberId));
		}else
			return new ResponseParam<>(1, "Parameter error!");
	}
	
	@RequestMapping(path="/findLastestHandle")
	public ResponseParam<AppointmentT> findLastestHandleView(@RequestBody Map<String, Object> params){
		if(params.containsKey("patientId")){
			
			Integer patientId=(Integer) params.get("patientId");
			return new ResponseParam<>(service.findLastestSuccessByPatientId(patientId));
		}else if(params.containsKey("doctorId") && params.containsKey("memberId")){
			Integer doctorId=(Integer) params.get("doctorId");
			Integer memberId=(Integer) params.get("memberId");
			
			return new ResponseParam<>(service.findLastestSuccess(doctorId, memberId));
		}else
			return new ResponseParam<>(1, "Parameter error!");
	}
	
	
	@RequestMapping(path="/listAllAll",method=RequestMethod.GET)
	public ResponseParam<AppointmentT> findAll(){
		List<AppointmentT> dataList=service.findAllAll();
		
		return new ResponseParam<>(dataList);
		
		
	}
	
	@RequestMapping(path="/update",method=RequestMethod.POST,consumes="application/json;charset=utf-8")
	public ResponseParam<AppointmentT> update(@RequestBody AppointmentT appointment){
		service.update(appointment);
		return new ResponseParam<>();
	}
	
	@RequestMapping(path="/findViewByMemberId/memberId={memberId}",method=RequestMethod.GET)
	public ResponseParam<AppointmentTView> findViewByMemberId(@PathVariable("memberId") Integer memberId){
		return new ResponseParam<>(service.findViewByMemberId(memberId));
	}
	
	@RequestMapping(path="/findViewByDoctorId/doctorId={doctorId}",method=RequestMethod.GET)
	public ResponseParam<AppointmentTView> findViewByDoctorId(@PathVariable("doctorId") Integer doctorId){
		List<AppointmentTView> viewList=service.findViewByDoctorId(doctorId);
			for(AppointmentTView v:viewList){
				PatientT p=pService.findById(v.getP_id());
				MembersInfo mi=miService.findByMemberId(p.getMember_id());
				if(mi!=null){
					v.setPatient_age(AgeUtil.computeAgeByBirthday(mi.getBirthday()));
					v.setPatient_name(mi.getMembersname());
					v.setPatient_photo(mi.getPicture());
					v.setPatient_sex(mi.getSex());
				}
			}
			
			return new ResponseParam<>(viewList);
	}
	
	
	@RequestMapping(path="/getAppointmentStatus/doctorId={doctorId}",method=RequestMethod.GET)
	public ResponseParam<AppointmentDateTablet> getAppointmentStatus(@PathVariable("doctorId") Integer doctorId){
		List<AppointmentT> aList=service.findByDoctorId(doctorId);

		Calendar tCal=Calendar.getInstance();
				tCal.set(Calendar.HOUR_OF_DAY, 8);
				tCal.set(Calendar.MINUTE, 0);
				tCal.set(Calendar.SECOND, 0);
				tCal.set(Calendar.MILLISECOND, 0);
		
	 // already occupied
	   boolean[] dateIdxs=new boolean[19*10];
	   for(int k=0;k<dateIdxs.length;k++){
		   dateIdxs[k]=false;
	   }
		
	   for(AppointmentT a:aList){
		   //check state of appointment
		   if(a.getState()<2){
			   
			   Date startDate=a.getAppoint_time_start();
			   Date endDate=a.getAppoint_time_end();
			   
			   long startDateMillis=a.getAppoint_date().getTime()+a.getAppoint_time_start().getTime();
			   long endDateMillis=a.getAppoint_date().getTime()+a.getAppoint_time_end().getTime();
			   

			   	
			   	//log.info("year:"+startCal.get(Calendar.YEAR)+"month:"+(startCal.get(Calendar.MONTH)+1)+"day:"+startCal.get(Calendar.DAY_OF_MONTH));
			   
			   
			   int dayDiff=(int)(startDateMillis-tCal.getTimeInMillis())/(1000*24*60*60);
			   
			   
			   Calendar cal=Calendar.getInstance();
			   	cal.setTime(startDate);
				   	cal.set(Calendar.HOUR_OF_DAY, 8);
				   	cal.set(Calendar.MINUTE, 0);
				   	cal.set(Calendar.SECOND, 0);
				   	cal.set(Calendar.MILLISECOND, 0);
			   
				int startDiff=(int)((startDate.getTime()-cal.getTimeInMillis())/(1000*60*60/2));
				int diffCount=(int)(endDate.getTime()-startDate.getTime())/(1000*60*60/2);
				
				int startIndex=dayDiff*19+startDiff;
				int endIndex=startIndex+diffCount;
				
				//check  startIndex and endIndex
				
				log.info("dayDiff"+dayDiff+" startDiff:"+startDiff+" diffCount:"+diffCount);
				log.info("startIndex:"+startIndex+" endIndex:"+endIndex);
				
				
				if(startIndex>=0 && endIndex>0 && startIndex<190-1 && endIndex<190*10){
					for(int i=startIndex;i<endIndex;i++){
						dateIdxs[i]=true;
					}
				}
		   }
	   }
	   
	   //cancel unwork
	   List<AppointmentDateTablet> dateTabletList=new ArrayList<>();
	   //generate tablet
	   for(int d=0;d<10;d++){
		   AppointmentDateTablet tablet=new AppointmentDateTablet();
		   if(d!=0){
			   tCal.add(Calendar.DATE, 1);
		   }
		  int month=tCal.get(Calendar.MONTH)+1;
		  int dom=tCal.get(Calendar.DAY_OF_MONTH);
		  
		  String dateStr=(month<10?"0"+month:month+"")+"/"+(dom<10?"0"+dom:dom+"");
		  String weekStr=null;
		  int dow=tCal.get(Calendar.DAY_OF_WEEK);
		  switch(dow){
		  case 1:
			  weekStr="星期日";
			  break;
		  case 2:
			  weekStr="星期一";
			  break;
		  case 3:
			  weekStr="星期二";
			  break;
		  case 4:
			  weekStr="星期三";
			  break;
		  case 5:
			  weekStr="星期四";
			  break;
		  case 6:
			  weekStr="星期五";
			  break;
		  case 7:
			  weekStr="星期六";
			  break;
		  }

		   tablet.setDate(dateStr);
		   tablet.setWeek(weekStr);
		   
		   List<Map<String, Object>> data=new ArrayList<>();
		   boolean dateStatus=false;
		   
		   for(int h=0;h<19;h++){
			  
			   String startTimeStr=null;
			   String endTimeStr=null;
			   
			   int val=8+h/2;
			   if(h%2==0){
				   startTimeStr=((val)<10?"0"+val:val)+":00";
				   endTimeStr=((val)<10?"0"+val:val)+":30";
			   }else{
				   startTimeStr=((val)<10?"0"+val:val)+":30";
				   endTimeStr=((val+1)<10?"0"+(val+1):val+1)+":00";
			   }
			   
			   Map<String, Object> timeMap=new HashMap<>();
			   	timeMap.put("time", startTimeStr+"~"+endTimeStr);
			   	
			   	
			   	timeMap.put("timestauts", !dateIdxs[d*19+h]);
			   	
			   	data.add(timeMap);
			   	
			   	if(!dateIdxs[d*19+h]) dateStatus=true;
		   }
		   
		   tablet.setDatestatus(dateStatus);
		   tablet.setData(data);
		   
		   dateTabletList.add(tablet);
		   
	   }
	   
		return new ResponseParam<AppointmentDateTablet>(dateTabletList);
	}
}
