package zdfs.util;

import java.util.TimeZone;

import com.fasterxml.jackson.databind.ObjectMapper;

public class CustomerObjectMapper extends ObjectMapper{

	public CustomerObjectMapper() {
		// TODO Auto-generated constructor stub
		TimeZone timeZone=TimeZone.getTimeZone("GMT-08:00");
		//TimeZone timeZone=TimeZone.getDefault();
		this.setTimeZone(timeZone);
	}
}
